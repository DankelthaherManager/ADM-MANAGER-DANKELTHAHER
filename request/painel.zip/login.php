<!DOCTYPE html>
<html>
<head>
	<!-- PRESERVE O ORIGINAL FOI FEITO COM CARINHO PENSANDO EM VOCE
		 TELEGRAM: t.me/digitandoo
		 DATA: 26/10/2017
		 =================================================================
		         +++++++++++++++++ ATENÇÃO +++++++++++++++++++++ 
		 NAO MECHA NA ONDE NAO SABE ESSE PAINE NAO TEM ASSISTENCIA
		 ELE FOI ENTREGUE A VOCE FUNCIONANDO PERFEITO ENTAO SE FOR ALTERAR
		 É BOM SABER AONDE TA MEXENDO 
		 ================================================================== 
	!-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <title>Login | Adm Upload</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
 </head>
<body>
<section class="cid-qz6iJf2irS mbr-fullscreen" id="header15-k" data-rv-view="15">
    <div class="container align-right">
<div class="row">
    <div class="mbr-white col-lg-8 col-md-7 content-container">
        <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-2">ADM-NEW ULTIMATE</h1>
        <p class="mbr-text pb-3 mbr-fonts-style display-5"></p><p>&nbsp;Control de acesso&nbsp;&nbsp;&nbsp;<br>&nbsp;Bienvenido&nbsp;&nbsp;&nbsp;<br></p><p></p>
    </div>
    <div class="col-lg-4 col-md-5">
    <div class="form-container">
        <div class="media-container-column" data-form-type="formoid">
				<form class="mbr-form" action="validacao.php" method="post">
                <div data-for="name">
                    <div class="form-group">
                        <input type="text" class="form-control px-3" name="login" data-form-field="Name" placeholder="Login" required="" id="name-header15-k">
                    </div>
                </div>
                <div data-for="senha">
                    <div class="form-group">
                        <input type="password" class="form-control px-3" name="senha" data-form-field="senha" placeholder="Senha" required="" id="senha-header15-k">
                    </div>
                </div>
                <span class="input-group-btn"><button href="" type="submit" class="btn btn-form btn-info display-4">ENTRAR</button></span>
            </form>
        </div>
    </div>
    </div>
</div>
    </div>  
</section>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <div id="scrollToTop" class="scrollToTop mbr-arrow-up">
  <a style="text-align: center;">
  <i class="mbri-down mbr-iconfont">
  </i>
  </a>
  </div>
  </body>
</html>